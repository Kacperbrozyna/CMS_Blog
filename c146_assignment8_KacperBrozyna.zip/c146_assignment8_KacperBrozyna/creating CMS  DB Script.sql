DROP DATABASE IF EXISTS cmsblogdb;
CREATE DATABASE cmsblogdb;

use cmsblogdb;

create table category(
id int primary key auto_increment,
categoryTag varchar(30) not null
);

create table blog(
id int primary key auto_increment,
dateOfBlog timeStamp not null,
title varchar(50) not null,
blogEntry text,
author varchar(35) not null,
categoryId int not null,
foreign key(categoryId) references category(id)
); 

create table hashtag(
id int primary key auto_increment,
hashtagTag varchar(30) not null);

create table hashtagBlog(
blogId int not null, 
hashtagId int not null,
primary key(blogId, hashtagId),
foreign key(blogId) references blog(id),
foreign key(hashtagId) references hashtag(id)
);

insert into category(categoryTag) values
("Blog");

insert into blog(dateOfBlog, title, blogEntry, author, categoryId) values
('2019-01-10 12:34:45', "First Blog Ever!", "So, here we are doing our first blog ever. I hope you enjoy it and stay for further posts", "Kacper 'Tester' Brozyna", 1),
('2019-01-11 12:34:45', "Second Blog Ever!", "So, here we are doing our second blog ever. This one is kinda short", "Kacper 'Tester' Brozyna", 1);

insert into hashtag(hashtagTag) values
("#FirstForEverything"),
("#MyBlog"),
("#HereWeGoAgain");

insert into hashtagBlog(blogId, hashtagId) values
(1,1),
(1,2),
(2,2),
(2,3);